# 🚀 دليل النشر على Render.com

## 📋 نظرة عامة

هذا الدليل يشرح كيفية نشر بوت الواتساب على Render.com مع حل مشكلة التخزين الدائم باستخدام MongoDB.

---

## ⚠️ قبل البدء

### المتطلبات:
- ✅ حساب على [Render.com](https://render.com) (مجاني)
- ✅ حساب MongoDB Atlas (مجاني)
- ✅ حساب GitHub (لرفع الكود)

### القيود المهمة:
- ⚠️ البوت **ينام** بعد 15 دقيقة من عدم النشاط
- ⚠️ **750 ساعة** مجانية فقط شهرياً (≈ 31 يوم إذا عمل 24/7)
- ⚠️ يحتاج تعديل الكود لاستخدام MongoDB للجلسات

---

## 🔧 الخطوة 1: تعديل الكود لاستخدام MongoDB

### 1.1 تثبيت المكتبات المطلوبة

```bash
cd "c:\Users\diya\Desktop\whatsapp_api_bot_project (1)"
npm install wwebjs-mongo mongoose
```

### 1.2 إنشاء ملف جديد: `auth-strategy.js`

سأنشئ هذا الملف في الخطوة التالية...

### 1.3 تعديل `index.js`

سنحتاج لتعديل طريقة المصادقة من `LocalAuth` إلى `RemoteAuth`.

---

## 🗄️ الخطوة 2: إعداد MongoDB Atlas

### 2.1 إنشاء حساب مجاني:
1. اذهب إلى [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register)
2. سجّل حساب جديد (مجاني)
3. اختر **M0 Free Tier** (512 MB مجاني)

### 2.2 إنشاء Cluster:
1. اختر **AWS** كمزود
2. اختر أقرب منطقة (مثل: Frankfurt, Germany)
3. اضغط **Create Cluster**

### 2.3 إعداد الوصول:
1. **Database Access:**
   - اذهب إلى **Database Access**
   - اضغط **Add New Database User**
   - اختر **Password** authentication
   - Username: `whatsapp_bot`
   - Password: (احفظه!)
   - Database User Privileges: **Read and write to any database**

2. **Network Access:**
   - اذهب إلى **Network Access**
   - اضغط **Add IP Address**
   - اختر **Allow Access from Anywhere** (0.0.0.0/0)
   - اضغط **Confirm**

### 2.4 الحصول على Connection String:
1. اذهب إلى **Database** → **Connect**
2. اختر **Connect your application**
3. انسخ الـ Connection String:
   ```
   mongodb+srv://whatsapp_bot:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
4. استبدل `<password>` بكلمة المرور الحقيقية

---

## 📦 الخطوة 3: رفع الكود على GitHub

### 3.1 إنشاء Repository:
1. اذهب إلى [GitHub](https://github.com)
2. اضغط **New Repository**
3. الاسم: `whatsapp-bot`
4. اختر **Private** (للأمان)
5. اضغط **Create repository**

### 3.2 رفع الكود:
```bash
cd "c:\Users\diya\Desktop\whatsapp_api_bot_project (1)"

# تهيئة Git
git init
git add .
git commit -m "Initial commit for Render deployment"

# ربط بـ GitHub
git remote add origin https://github.com/YOUR_USERNAME/whatsapp-bot.git
git branch -M main
git push -u origin main
```

---

## 🌐 الخطوة 4: النشر على Render

### 4.1 إنشاء Web Service:
1. اذهب إلى [Render Dashboard](https://dashboard.render.com/)
2. اضغط **New** → **Web Service**
3. اختر **Build and deploy from a Git repository**
4. اضغط **Next**

### 4.2 ربط GitHub:
1. اضغط **Connect GitHub**
2. اختر repository: `whatsapp-bot`
3. اضغط **Connect**

### 4.3 إعدادات Service:

| الحقل | القيمة |
|-------|--------|
| **Name** | `whatsapp-bot` (أو أي اسم) |
| **Region** | اختر أقرب منطقة |
| **Branch** | `main` |
| **Root Directory** | (اتركه فارغاً) |
| **Runtime** | `Node` |
| **Build Command** | `npm install` |
| **Start Command** | `node index.js` |
| **Instance Type** | **Free** |

### 4.4 إضافة Environment Variables:

اضغط **Advanced** ثم **Add Environment Variable**:

| Key | Value |
|-----|-------|
| `MONGODB_URI` | (Connection String من MongoDB) |
| `API_KEY` | (مفتاح سري قوي) |
| `PORT` | `10000` |
| `CHROME_PATH` | `/usr/bin/google-chrome-stable` |
| `PUPPETEER_SKIP_CHROMIUM_DOWNLOAD` | `true` |
| `PUPPETEER_EXECUTABLE_PATH` | `/usr/bin/google-chrome-stable` |
| `NODE_ENV` | `production` |

### 4.5 إنشاء Service:
اضغط **Create Web Service**

---

## 🐳 الخطوة 5: إنشاء Dockerfile (مهم!)

Render يحتاج Dockerfile لتثبيت Chrome. سأنشئه في الخطوة التالية...

---

## 📱 الخطوة 6: مسح QR Code

### 6.1 انتظر حتى ينتهي البناء:
- راقب Logs في Render Dashboard
- انتظر حتى ترى: `🚀 WhatsApp Dual Bot Server Running`

### 6.2 افتح المتصفح:
```
https://whatsapp-bot.onrender.com/qr
```
(استبدل `whatsapp-bot` باسم service الخاص بك)

### 6.3 امسح QR Code:
- اضغط **OTP Client QR**
- امسح بتطبيق WhatsApp
- اضغط **Notifications QR**
- امسح بتطبيق WhatsApp الثاني

---

## ⚡ الخطوة 7: حل مشكلة Spin Down

### المشكلة:
Render Free Tier ينيّم البوت بعد 15 دقيقة من عدم النشاط.

### الحل 1: Cron Job خارجي (مجاني)
استخدم خدمة مثل [cron-job.org](https://cron-job.org):

1. سجّل حساب مجاني
2. أنشئ Cron Job جديد:
   - **URL:** `https://whatsapp-bot.onrender.com/status`
   - **Interval:** كل 10 دقائق
   - **Method:** GET

### الحل 2: UptimeRobot (مجاني)
1. اذهب إلى [UptimeRobot](https://uptimerobot.com)
2. أنشئ Monitor جديد:
   - **Monitor Type:** HTTP(s)
   - **URL:** `https://whatsapp-bot.onrender.com/status`
   - **Monitoring Interval:** 5 دقائق

---

## 🔍 الخطوة 8: المراقبة

### عرض Logs:
```
Render Dashboard → Your Service → Logs
```

### التحقق من الحالة:
```
https://whatsapp-bot.onrender.com/status
```

---

## 🆘 حل المشاكل الشائعة

### المشكلة 1: Chrome لا يعمل
**الحل:** تأكد من وجود Dockerfile الصحيح (سأنشئه)

### المشكلة 2: البوت يتوقف باستمرار
**الحل:** استخدم UptimeRobot لإبقائه نشطاً

### المشكلة 3: فقدان الجلسات
**الحل:** تأكد من استخدام `RemoteAuth` مع MongoDB

### المشكلة 4: Build يفشل
**الحل:** تحقق من:
- ✅ `package.json` موجود
- ✅ جميع Dependencies مثبتة
- ✅ Dockerfile موجود

---

## 💰 التكلفة

### Free Tier:
- ✅ 750 ساعة/شهر مجاناً
- ✅ 100 GB Bandwidth
- ✅ 500 Build Minutes

### إذا تجاوزت الحد:
- ⚠️ سيتم إيقاف جميع الخدمات المجانية
- ⚠️ لن يتم فرض رسوم إضافية
- ⚠️ ستعود للعمل في الشهر التالي

---

## 📊 المقارنة: Render vs VPS

| الميزة | Render Free | VPS ($6.88/شهر) |
|--------|-------------|------------------|
| **السعر** | 🏆 مجاني | $6.88/شهر |
| **الاستقرار** | ⚠️ متوسط | 🏆 ممتاز |
| **Spin Down** | ❌ ينام | 🏆 دائماً نشط |
| **التخزين** | ❌ يحتاج MongoDB | 🏆 مباشر |
| **الموارد** | ⚠️ محدودة | 🏆 2GB RAM |
| **التحكم** | ⚠️ محدود | 🏆 كامل |

---

## ✅ الخلاصة

### Render مناسب إذا:
- ✅ تريد تجربة مجانية
- ✅ لا تمانع في Spin Down
- ✅ الاستخدام خفيف

### VPS أفضل إذا:
- ✅ تريد استقرار 24/7
- ✅ تريد أداء أفضل
- ✅ تريد تحكم كامل

---

## 📞 الخطوات التالية

سأنشئ الآن:
1. ملف `auth-strategy.js` للمصادقة عبر MongoDB
2. تعديلات على `index.js`
3. `Dockerfile` لـ Render
4. `render.yaml` للإعدادات

هل تريد المتابعة؟
