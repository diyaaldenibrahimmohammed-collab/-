# 📦 ملفات النشر (Deployment Files)

هذا المجلد يحتوي على جميع الملفات والسكريبتات المطلوبة لنشر البوت على VPS.

## 📁 محتويات المجلد

### 1. `setup-vps.sh`
**الوصف:** سكريبت إعداد السيرفر الأولي  
**الاستخدام:** يُنفذ مرة واحدة على VPS جديد لتثبيت كل البرامج المطلوبة

```bash
# على السيرفر (VPS)
wget https://raw.githubusercontent.com/YOUR_REPO/deploy/setup-vps.sh
chmod +x setup-vps.sh
sudo bash setup-vps.sh
```

**ماذا يفعل:**
- ✅ يحدّث النظام
- ✅ يثبت Node.js 20 LTS
- ✅ يثبت Google Chrome
- ✅ يثبت PM2
- ✅ يثبت Git
- ✅ يثبت Nginx (اختياري)
- ✅ يعد Firewall

---

### 2. `quick-deploy.sh`
**الوصف:** سكريبت النشر السريع  
**الاستخدام:** يُنفذ من جهازك المحلي لرفع التحديثات على السيرفر

```bash
# على جهازك المحلي
cd "c:\Users\diya\Desktop\whatsapp_api_bot_project (1)"

# عدّل الإعدادات في السكريبت أولاً
nano deploy/quick-deploy.sh

# نفذ السكريبت
bash deploy/quick-deploy.sh
```

**ماذا يفعل:**
- ✅ يضغط الملفات المطلوبة فقط
- ✅ يرفعها على السيرفر
- ✅ يثبت Dependencies
- ✅ يعيد تشغيل البوت تلقائياً

---

### 3. `nginx.conf`
**الوصف:** إعدادات Nginx  
**الاستخدام:** لإعداد Reverse Proxy والـ SSL

```bash
# على السيرفر
sudo cp /var/www/whatsapp-bot/deploy/nginx.conf /etc/nginx/sites-available/whatsapp-bot

# عدّل الدومين
sudo nano /etc/nginx/sites-available/whatsapp-bot

# تفعيل الإعداد
sudo ln -s /etc/nginx/sites-available/whatsapp-bot /etc/nginx/sites-enabled/

# اختبار الإعداد
sudo nginx -t

# إعادة تشغيل Nginx
sudo systemctl restart nginx
```

---

## 🚀 خطوات النشر الكاملة

### المرة الأولى (Initial Setup):

#### 1. على السيرفر (VPS):
```bash
# تسجيل الدخول
ssh root@YOUR_SERVER_IP

# تحميل وتنفيذ سكريبت الإعداد
wget https://raw.githubusercontent.com/YOUR_REPO/deploy/setup-vps.sh
chmod +x setup-vps.sh
sudo bash setup-vps.sh
```

#### 2. على جهازك المحلي:
```bash
# رفع الملفات
cd "c:\Users\diya\Desktop\whatsapp_api_bot_project (1)"

# عدّل إعدادات quick-deploy.sh
nano deploy/quick-deploy.sh
# غيّر SERVER_IP إلى IP السيرفر الخاص بك

# نفذ النشر
bash deploy/quick-deploy.sh
```

#### 3. إعداد ملف .env على السيرفر:
```bash
ssh root@YOUR_SERVER_IP

cd /var/www/whatsapp-bot
nano .env

# أضف الإعدادات:
# MONGODB_URI=...
# API_KEY=...
# CHROME_PATH=/usr/bin/google-chrome
```

#### 4. بدء البوت:
```bash
cd /var/www/whatsapp-bot
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

#### 5. مسح QR Code:
```bash
# افتح المتصفح
http://YOUR_SERVER_IP:3000/qr
```

---

### التحديثات اللاحقة (Updates):

```bash
# على جهازك المحلي فقط
cd "c:\Users\diya\Desktop\whatsapp_api_bot_project (1)"
bash deploy/quick-deploy.sh
```

---

## 🔧 أوامر مفيدة

### PM2:
```bash
pm2 status                  # عرض الحالة
pm2 logs whatsapp-bot       # عرض السجلات
pm2 restart whatsapp-bot    # إعادة التشغيل
pm2 stop whatsapp-bot       # إيقاف
pm2 delete whatsapp-bot     # حذف
pm2 monit                   # مراقبة الموارد
```

### Nginx:
```bash
sudo nginx -t               # اختبار الإعداد
sudo systemctl restart nginx # إعادة التشغيل
sudo systemctl status nginx  # عرض الحالة
```

### Logs:
```bash
# سجلات PM2
pm2 logs whatsapp-bot

# سجلات Nginx
sudo tail -f /var/log/nginx/whatsapp-bot-access.log
sudo tail -f /var/log/nginx/whatsapp-bot-error.log

# سجلات النظام
journalctl -u nginx -f
```

---

## 🆘 حل المشاكل

### المشكلة: البوت لا يبدأ
```bash
# تحقق من السجلات
pm2 logs whatsapp-bot --lines 50

# تحقق من ملف .env
cat /var/www/whatsapp-bot/.env

# تحقق من Chrome
google-chrome --version
```

### المشكلة: لا يمكن الوصول للبوت من الخارج
```bash
# تحقق من Firewall
sudo ufw status

# افتح البورت
sudo ufw allow 3000/tcp

# تحقق من أن البوت يعمل
curl http://localhost:3000/status
```

### المشكلة: نفاد الذاكرة
```bash
# زيادة حد الذاكرة
pm2 delete whatsapp-bot
pm2 start ecosystem.config.js --max-memory-restart 700M
pm2 save
```

---

## 📞 الدعم

إذا واجهت أي مشكلة:
1. تحقق من السجلات: `pm2 logs whatsapp-bot`
2. تحقق من حالة النظام: `htop`
3. تحقق من اتصال MongoDB: `curl -I $MONGODB_URI`

---

## 🔐 الأمان

### توصيات:
- ✅ استخدم مفتاح SSH بدلاً من كلمة المرور
- ✅ غيّر البورت الافتراضي لـ SSH (22)
- ✅ فعّل Fail2ban لحماية من الهجمات
- ✅ استخدم SSL/HTTPS دائماً
- ✅ احتفظ بنسخ احتياطية من مجلد sessions

```bash
# تثبيت Fail2ban
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
```

---

## 📊 المراقبة

### إعداد مراقبة تلقائية:
```bash
# تثبيت PM2 Plus (اختياري)
pm2 install pm2-server-monit

# أو استخدم Netdata
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

---

**آخر تحديث:** 2026-01-25
