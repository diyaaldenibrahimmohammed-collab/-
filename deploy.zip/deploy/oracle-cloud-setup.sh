#!/bin/bash

# Oracle Cloud Instance Setup Script for WhatsApp Bot
# This script automates the setup of a fresh Oracle Cloud instance

set -e  # Exit on error

echo "=========================================="
echo "WhatsApp Bot - Oracle Cloud Setup"
echo "=========================================="

# Update system packages
echo "📦 Updating system packages..."
sudo yum update -y || sudo apt-get update -y

# Install Node.js (using NodeSource repository for latest LTS)
echo "📦 Installing Node.js..."
if command -v yum &> /dev/null; then
    # Oracle Linux / CentOS / RHEL
    curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
    sudo yum install -y nodejs
else
    # Ubuntu / Debian
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Verify Node.js installation
node --version
npm --version

# Install Chrome/Chromium for Puppeteer
echo "🌐 Installing Chrome/Chromium..."
if command -v yum &> /dev/null; then
    # Oracle Linux
    sudo yum install -y chromium
else
    # Ubuntu
    sudo apt-get install -y chromium-browser
fi

# Install Git (if not already installed)
echo "📦 Installing Git..."
if command -v yum &> /dev/null; then
    sudo yum install -y git
else
    sudo apt-get install -y git
fi

# Install PM2 globally for process management
echo "📦 Installing PM2..."
sudo npm install -g pm2

# Configure firewall to allow HTTP/HTTPS traffic
echo "🔥 Configuring firewall..."
if command -v firewall-cmd &> /dev/null; then
    # Oracle Linux firewalld
    sudo firewall-cmd --permanent --add-service=http
    sudo firewall-cmd --permanent --add-service=https
    sudo firewall-cmd --permanent --add-port=3000/tcp
    sudo firewall-cmd --reload
else
    # Ubuntu UFW
    sudo ufw allow 80/tcp
    sudo ufw allow 443/tcp
    sudo ufw allow 3000/tcp
fi

# Create application directory
echo "📁 Creating application directory..."
sudo mkdir -p /opt/whatsapp-bot
sudo chown -R $USER:$USER /opt/whatsapp-bot

# Create sessions directory
mkdir -p /opt/whatsapp-bot/sessions

echo ""
echo "✅ Oracle Cloud instance setup completed!"
echo ""
echo "Next steps:"
echo "1. Clone your repository: cd /opt/whatsapp-bot && git clone <your-repo-url> ."
echo "2. Copy .env file: cp .env.example .env"
echo "3. Edit .env with your credentials: nano .env"
echo "4. Install dependencies: npm install"
echo "5. Set up systemd service (see whatsapp-bot.service)"
echo "6. Start the service: sudo systemctl start whatsapp-bot"
echo ""
