#!/bin/bash

# ========================================
# 🚀 Quick Deploy Script
# ========================================
# هذا السكريبت يقوم برفع البوت على السيرفر بسرعة
# الاستخدام: bash quick-deploy.sh

set -e

# ========================================
# الإعدادات - عدّل هذه القيم
# ========================================
SERVER_IP="YOUR_SERVER_IP"           # مثال: 123.45.67.89
SERVER_USER="root"                   # عادةً root
PROJECT_PATH="/var/www/whatsapp-bot"
LOCAL_PATH="."                       # المجلد الحالي

# ========================================
# الألوان للطباعة
# ========================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ========================================
# دالة للطباعة الملونة
# ========================================
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# ========================================
# التحقق من الإعدادات
# ========================================
if [ "$SERVER_IP" = "YOUR_SERVER_IP" ]; then
    print_error "يرجى تعديل SERVER_IP في السكريبت أولاً!"
    exit 1
fi

# ========================================
# 1️⃣ إنشاء ملف مؤقت للملفات المطلوبة
# ========================================
print_info "إنشاء أرشيف للملفات..."

# إنشاء مجلد مؤقت
TEMP_DIR=$(mktemp -d)
ARCHIVE_NAME="whatsapp-bot-$(date +%Y%m%d-%H%M%S).tar.gz"

# نسخ الملفات المطلوبة فقط
rsync -av \
    --exclude 'node_modules' \
    --exclude '.git' \
    --exclude 'sessions' \
    --exclude '.wwebjs_cache' \
    --exclude 'logs' \
    --exclude '.env' \
    --exclude '*.tar.gz' \
    "$LOCAL_PATH/" "$TEMP_DIR/"

# إنشاء الأرشيف
cd "$TEMP_DIR"
tar -czf "/tmp/$ARCHIVE_NAME" .
cd -

print_info "تم إنشاء الأرشيف: /tmp/$ARCHIVE_NAME"

# ========================================
# 2️⃣ رفع الأرشيف إلى السيرفر
# ========================================
print_info "رفع الملفات إلى السيرفر..."

scp "/tmp/$ARCHIVE_NAME" "$SERVER_USER@$SERVER_IP:/tmp/"

# ========================================
# 3️⃣ فك الضغط وتثبيت Dependencies
# ========================================
print_info "فك الضغط وتثبيت Dependencies..."

ssh "$SERVER_USER@$SERVER_IP" << EOF
    set -e
    
    # إنشاء المجلد إذا لم يكن موجوداً
    mkdir -p $PROJECT_PATH
    
    # فك الضغط
    cd $PROJECT_PATH
    tar -xzf /tmp/$ARCHIVE_NAME
    
    # حذف الأرشيف المؤقت
    rm /tmp/$ARCHIVE_NAME
    
    # تثبيت Dependencies
    echo "📦 تثبيت Dependencies..."
    npm install --production
    
    # إنشاء مجلد logs إذا لم يكن موجوداً
    mkdir -p logs
    
    echo "✅ اكتمل فك الضغط والتثبيت"
EOF

# ========================================
# 4️⃣ التحقق من وجود ملف .env
# ========================================
print_warn "تحقق من وجود ملف .env على السيرفر..."

ssh "$SERVER_USER@$SERVER_IP" << EOF
    if [ ! -f "$PROJECT_PATH/.env" ]; then
        echo "⚠️  ملف .env غير موجود!"
        echo "📝 إنشاء ملف .env من .env.example..."
        cp "$PROJECT_PATH/.env.example" "$PROJECT_PATH/.env"
        echo "❗ يرجى تعديل ملف .env بالإعدادات الصحيحة"
        echo "   نفذ: nano $PROJECT_PATH/.env"
    else
        echo "✅ ملف .env موجود"
    fi
EOF

# ========================================
# 5️⃣ إعادة تشغيل البوت باستخدام PM2
# ========================================
print_info "إعادة تشغيل البوت..."

ssh "$SERVER_USER@$SERVER_IP" << EOF
    cd $PROJECT_PATH
    
    # التحقق من وجود PM2
    if ! command -v pm2 &> /dev/null; then
        echo "❌ PM2 غير مثبت! يرجى تثبيته أولاً"
        echo "   نفذ: npm install -g pm2"
        exit 1
    fi
    
    # إعادة تشغيل أو بدء البوت
    if pm2 list | grep -q "whatsapp-bot"; then
        echo "🔄 إعادة تشغيل البوت..."
        pm2 restart whatsapp-bot
    else
        echo "🚀 بدء البوت لأول مرة..."
        pm2 start ecosystem.config.js
        pm2 save
    fi
    
    # عرض الحالة
    pm2 status
EOF

# ========================================
# 6️⃣ تنظيف الملفات المؤقتة
# ========================================
print_info "تنظيف الملفات المؤقتة..."
rm -rf "$TEMP_DIR"
rm "/tmp/$ARCHIVE_NAME"

# ========================================
# ✅ اكتمل النشر
# ========================================
echo ""
print_info "=========================================="
print_info "✅ اكتمل النشر بنجاح!"
print_info "=========================================="
echo ""
print_info "للتحقق من السجلات: ssh $SERVER_USER@$SERVER_IP 'pm2 logs whatsapp-bot'"
print_info "للتحقق من الحالة: ssh $SERVER_USER@$SERVER_IP 'pm2 status'"
print_info "للوصول إلى البوت: http://$SERVER_IP:3000"
echo ""
