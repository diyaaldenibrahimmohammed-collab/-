#!/bin/bash

# ========================================
# 🚀 WhatsApp Bot VPS Setup Script
# ========================================
# هذا السكريبت يقوم بتثبيت كل البرامج المطلوبة على VPS جديد
# الاستخدام: bash setup-vps.sh

set -e  # إيقاف عند أي خطأ

echo "=========================================="
echo "🚀 بدء إعداد السيرفر لبوت الواتساب"
echo "=========================================="

# ========================================
# 1️⃣ تحديث النظام
# ========================================
echo ""
echo "📦 تحديث النظام..."
apt update && apt upgrade -y

# ========================================
# 2️⃣ تثبيت Node.js 20 LTS
# ========================================
echo ""
echo "📦 تثبيت Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "✅ Node.js version: $(node --version)"
echo "✅ NPM version: $(npm --version)"

# ========================================
# 3️⃣ تثبيت Chrome ومكتباته
# ========================================
echo ""
echo "📦 تثبيت Chrome والمكتبات المطلوبة..."

# تثبيت المكتبات
apt install -y \
    wget \
    gnupg \
    ca-certificates \
    fonts-liberation \
    libasound2 \
    libatk-bridge2.0-0 \
    libatk1.0-0 \
    libatspi2.0-0 \
    libcups2 \
    libdbus-1-3 \
    libdrm2 \
    libgbm1 \
    libgtk-3-0 \
    libnspr4 \
    libnss3 \
    libwayland-client0 \
    libxcomposite1 \
    libxdamage1 \
    libxfixes3 \
    libxkbcommon0 \
    libxrandr2 \
    xdg-utils

# تثبيت Google Chrome
echo "📦 تحميل وتثبيت Google Chrome..."
wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt install -y ./google-chrome-stable_current_amd64.deb
rm google-chrome-stable_current_amd64.deb

echo "✅ Chrome installed: $(google-chrome --version)"

# ========================================
# 4️⃣ تثبيت PM2
# ========================================
echo ""
echo "📦 تثبيت PM2..."
npm install -g pm2

echo "✅ PM2 version: $(pm2 --version)"

# ========================================
# 5️⃣ تثبيت Git
# ========================================
echo ""
echo "📦 تثبيت Git..."
apt install -y git

echo "✅ Git version: $(git --version)"

# ========================================
# 6️⃣ تثبيت Nginx (اختياري)
# ========================================
echo ""
read -p "هل تريد تثبيت Nginx؟ (y/n): " install_nginx
if [[ $install_nginx == "y" || $install_nginx == "Y" ]]; then
    echo "📦 تثبيت Nginx..."
    apt install -y nginx
    systemctl enable nginx
    systemctl start nginx
    echo "✅ Nginx installed and started"
fi

# ========================================
# 7️⃣ إعداد Firewall
# ========================================
echo ""
echo "🔒 إعداد Firewall..."
ufw allow 22/tcp    # SSH
ufw allow 3000/tcp  # Bot Port
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
echo "y" | ufw enable

echo "✅ Firewall configured"

# ========================================
# 8️⃣ إنشاء مجلد المشروع
# ========================================
echo ""
echo "📁 إنشاء مجلد المشروع..."
mkdir -p /var/www/whatsapp-bot
chown -R $USER:$USER /var/www/whatsapp-bot

echo "✅ Project directory created: /var/www/whatsapp-bot"

# ========================================
# ✅ اكتمل الإعداد
# ========================================
echo ""
echo "=========================================="
echo "✅ اكتمل إعداد السيرفر بنجاح!"
echo "=========================================="
echo ""
echo "الخطوات التالية:"
echo "1. ارفع ملفات البوت إلى: /var/www/whatsapp-bot"
echo "2. أنشئ ملف .env بالإعدادات المطلوبة"
echo "3. نفذ: cd /var/www/whatsapp-bot && npm install"
echo "4. نفذ: pm2 start ecosystem.config.js"
echo "5. نفذ: pm2 save && pm2 startup"
echo ""
echo "للتحقق من حالة البوت: pm2 status"
echo "لعرض السجلات: pm2 logs whatsapp-bot"
echo ""
