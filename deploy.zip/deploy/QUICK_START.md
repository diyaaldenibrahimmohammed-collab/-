# Quick Start Guide - Oracle Cloud

## 🚀 Fast Deployment (5 Minutes)

### Prerequisites
- Oracle Cloud account
- SSH key pair
- MongoDB Atlas connection string

---

## Step 1: Create Instance (2 min)

1. Login to [Oracle Cloud](https://cloud.oracle.com)
2. **Compute** → **Instances** → **Create Instance**
3. Settings:
   - **Shape**: VM.Standard.E2.1.Micro (Free Tier)
   - **Image**: Oracle Linux 8
   - **SSH Key**: Upload your public key
4. Note the **Public IP** address

---

## Step 2: Configure Firewall (1 min)

1. **Networking** → **Virtual Cloud Networks** → Your VCN
2. **Security Lists** → **Default Security List** → **Add Ingress Rules**:

```
Source: 0.0.0.0/0, Protocol: TCP, Port: 22   (SSH)
Source: 0.0.0.0/0, Protocol: TCP, Port: 80   (HTTP)
Source: 0.0.0.0/0, Protocol: TCP, Port: 443  (HTTPS)
Source: 0.0.0.0/0, Protocol: TCP, Port: 3000 (Bot API)
```

---

## Step 3: Deploy (2 min)

```bash
# SSH into instance
ssh -i your-key.pem opc@<PUBLIC_IP>

# Run automated setup
curl -fsSL https://raw.githubusercontent.com/your-repo/whatsapp-bot/main/deploy/oracle-cloud-setup.sh | bash

# Clone repository
cd /opt/whatsapp-bot
git clone https://github.com/your-repo/whatsapp-bot.git .

# Configure environment
cp .env.example .env
nano .env  # Add your API_KEY and MONGODB_URI

# Install and start
npm install
sudo cp deploy/whatsapp-bot.service /etc/systemd/system/
sudo systemctl enable --now whatsapp-bot
```

---

## Step 4: Initialize WhatsApp

1. Open browser: `http://<PUBLIC_IP>:3000/qr`
2. Scan QR codes for both clients
3. Done! ✅

---

## Verify Deployment

```bash
# Check service status
sudo systemctl status whatsapp-bot

# View logs
sudo journalctl -u whatsapp-bot -f

# Test API
curl http://localhost:3000/status
```

---

## 📚 Full Documentation

For detailed setup, troubleshooting, and advanced configuration, see:
- [`ORACLE_CLOUD_DEPLOYMENT.md`](file:///c:/Users/diya/Desktop/whatsapp_api_bot_project/ORACLE_CLOUD_DEPLOYMENT.md)
